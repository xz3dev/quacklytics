import { test, expect, type Locator } from "@playwright/test";
import { z } from "zod";
import {
  defaultInsights,
  insight,
  project,
} from "../../packages/contracts/src/index";

async function expectSideBySideBars(chart: Locator, count: number) {
  const bars = chart.locator(".ts-chart__bar-y rect");
  await expect
    .poll(async () =>
      bars.evaluateAll((elements, expectedCount) => {
        const bounds = elements
          .map((element) => element.getBoundingClientRect())
          .filter((rect) => rect.height > 0 && rect.width > 0)
          .sort((a, b) => a.x - b.x);
        return (
          bounds.length === expectedCount &&
          bounds.every((rect, index) => {
            const previous = bounds[index - 1];
            return !previous || previous.right <= rect.left;
          })
        );
      }, count),
    )
    .toBe(true);
}

test("all charts break down by properties, persist, and restore ungrouped results", async ({
  page,
  baseURL,
}) => {
  test.setTimeout(180000);
  page.on("console", (message) => { if (message.type() === "error") console.log("Browser error:", message.text()); });
  page.on("requestfailed", (request) => console.log("Failed request:", request.url(), request.failure()?.errorText));
  page.setDefaultTimeout(15000);
  const setup = z
    .object({ adminRegistered: z.boolean() })
    .parse(await (await page.request.get("/api/setup")).json());
  const login = await page.request.post(
    `/api/auth/${setup.adminRegistered ? "sign-in" : "sign-up"}/email`,
    {
      headers: { Origin: baseURL ?? "" },
      data: {
        email: "migration@example.com",
        password: "Migration-test-password-42",
        name: "Migration",
      },
    },
  );
  expect(login.ok(), await login.text()).toBeTruthy();
  const createdProject = project.parse(
    await (
      await page.request.post("/api/projects", {
        data: { name: "Breakdown charts" },
      })
    ).json(),
  );
  const keys = z
    .array(z.object({ key: z.string() }))
    .parse(
      await (
        await page.request.post(`/api/${createdProject.id}/apikeys`)
      ).json(),
    );
  const key = keys.at(-1)?.key;
  if (!key) throw new Error("Missing API key");
  const events = ["desktop", "mobile", null].flatMap((device, index) =>
    ["signup", "purchase"].map((eventType, step) => ({
      id: crypto.randomUUID(),
      eventType,
      personId: `person-${index}`,
      sessionId: `session-${index}`,
      timestamp: new Date(Date.now() - (3 - step) * 86400000).toISOString(),
      properties: device === null ? {} : { device },
    })),
  );
  const ingested = await page.request.post("/api/ingest", {
    headers: { "X-API-KEY": key },
    data: { requestId: crypto.randomUUID(), events },
  });
  expect(ingested.ok(), await ingested.text()).toBeTruthy();
  const ids: number[] = [];
  const errors: string[] = [];
  page.on("pageerror", (error) => errors.push(error.message));
  for (const definition of Object.values(defaultInsights)) {
    const configured = insight.parse({ ...definition, id: 1 });
    if (configured.type === "Trend") {
      const original = configured.config.trend.series?.[0];
      if (!original) throw new Error("Missing trend series");
      configured.config.trend.series = [
        { ...original, name: "Events", visualisation: "bar" },
        {
          ...original,
          name: "Purchases",
          visualisation: "bar",
          query: {
            ...original.query,
            filters: [
              {
                field: { name: "event_type", type: "string" },
                operator: "=",
                value: "purchase",
              },
            ],
          },
        },
      ];
    }
    if (configured.type === "Funnel") {
      configured.config.funnel.steps = ["signup", "purchase"].map(
        (name, order) => ({
          id: name,
          name,
          order,
          query: {
            filters: [
              {
                field: { name: "event_type", type: "string" },
                operator: "=",
                value: name,
              },
            ],
          },
        }),
      );
    }
    const response = await page.request.post(
      `/api/${createdProject.id}/insights`,
      { data: { ...configured, name: `Grouped ${definition.type}` } },
    );
    expect(response.ok(), await response.text()).toBeTruthy();
    const saved = insight.parse(await response.json());
    ids.push(saved.id);
    await page.goto(`/app/${createdProject.id}/insights/${saved.id}`);
    await page.setViewportSize({ width: 1440, height: 1000 });
    const plot = page.locator("[data-chart-minimum]");
    await expect(plot).toHaveCount(1);
    if (definition.type === "Trend") await expectSideBySideBars(plot, 3);
    const plotHeight = () =>
      plot.evaluate((element) => element.getBoundingClientRect().height);
    const layoutBottom = () =>
      page
        .locator("[data-chart-layout]")
        .evaluate(
          (element) => element.getBoundingClientRect().bottom + window.scrollY,
        );
    await expect.poll(layoutBottom).toBeGreaterThan(970);
    await expect.poll(layoutBottom).toBeLessThanOrEqual(977);
    const initialHeight = await plotHeight();
    await page.setViewportSize({ width: 1440, height: 1400 });
    await expect.poll(plotHeight).toBeGreaterThan(initialHeight + 390);
    await expect.poll(layoutBottom).toBeLessThanOrEqual(1377);
    if (definition.type !== "Value") {
      const graphic = plot.getByRole("img", {
        name: `Grouped ${definition.type}`,
        exact: true,
      });
      await expect
        .poll(() =>
          graphic.evaluate((element) => element.getBoundingClientRect().height),
        )
        .toBeGreaterThan(initialHeight + 390);
    }
    await page.screenshot({
      path: `output/chart-space-${definition.type.toLowerCase()}.png`,
      fullPage: true,
    });
    await page.setViewportSize({ width: 1440, height: 1000 });
    await expect.poll(plotHeight).toBeLessThan(initialHeight + 2);
    await page.setViewportSize({ width: 390, height: 844 });
    await expect
      .poll(() => page.evaluate(() => document.documentElement.scrollWidth))
      .toBeLessThanOrEqual(390);
    await expect(plot).toBeVisible();
    await page.setViewportSize({ width: 1440, height: 1000 });
    await page.getByRole("button", { name: "Edit", exact: true }).click();
    await page
      .getByRole("combobox")
      .filter({ hasText: "Select breakdown field" })
      .click();
    await page.getByPlaceholder("Search field...").fill("device");
    await page.getByRole("option").filter({ hasText: "device" }).click();
    const groups = page.getByTestId("breakdown-group");
    await expect(groups).toHaveCount(0);
    await expect(plot).toHaveCount(1);
    const chart = page.getByRole("img", {
      name: `Grouped ${definition.type}`,
      exact: true,
    });
    await expect(chart).toBeVisible();
    for (const label of ["desktop", "mobile", "(missing)"]) {
      if (definition.type === "Trend") {
        await expect(
          page
            .getByTestId("chart-series")
            .filter({ hasText: `Events · ${label}` }),
        ).toBeVisible();
        await expect(
          page
            .getByTestId("chart-series")
            .filter({ hasText: `Purchases · ${label}` }),
        ).toBeVisible();
      } else if (definition.type === "Path") {
        await expect(
          page.getByTestId("chart-series").getByText(label, { exact: true }),
        ).toBeVisible();
        await expect(page.getByText("purchase", { exact: true })).toHaveCount(
          3,
        );
      } else {
        const row = page.getByRole("row").filter({ hasText: label });
        if (definition.type === "Value") {
          await expect(row.getByRole("cell").nth(1)).toHaveText("2");
          await expect(row.getByRole("cell").nth(2)).toHaveText("0");
        } else if (definition.type === "Funnel") {
          await expect(
            row.filter({ hasText: "purchase" }).getByRole("cell").nth(1),
          ).toHaveText("1");
          await expect(row.filter({ hasText: "purchase" })).toContainText(
            "100.0%",
          );
        } else if (definition.type === "Breakdown") {
          await expect(
            row.filter({ hasText: "signup" }).getByRole("cell").nth(1),
          ).toHaveText("1");
        } else {
          await expect(row).toContainText("100%");
          await expect(row.getByRole("cell").nth(1)).toHaveText("1");
        }
      }
    }
    if (definition.type === "Trend") {
      await expect(page.getByTestId("chart-series")).toHaveCount(6);
      await expectSideBySideBars(chart, 9);
      await chart.hover({ position: { x: 400, y: 100 } });
      await expect(page.getByRole("status")).toHaveAccessibleName(
        /Events · desktop: 1/,
      );
      await expect(page.getByRole("status")).toHaveAccessibleName(
        /Events · mobile: 1/,
      );
      await expect(page.getByRole("status")).toHaveAccessibleName(
        /Events · \(missing\): 1/,
      );
    }
    await page.screenshot({
      path: `output/insight-sidebar-data-${definition.type.toLowerCase()}.png`,
      fullPage: true,
    });
    await expect(page.getByText(/Error:/)).toHaveCount(0);
    const save = page.waitForResponse(
      (r) =>
        r.url().endsWith(`/insights/${saved.id}`) &&
        r.request().method() === "PUT",
    );
    await page.getByRole("button", { name: "Save", exact: true }).click();
    const persisted = insight.parse(await (await save).json());
    expect(persisted.breakdownBy?.name).toContain("device");
    await page.reload();
    await expect(chart).toBeVisible();
    await expect(plot).toHaveCount(1);
    if (definition.type === "Trend") {
      await expectSideBySideBars(chart, 9);
    }
    await page.getByRole("button", { name: "Edit", exact: true }).click();
    await page.getByRole("button", { name: "Remove breakdown" }).click();
    await expect(groups).toHaveCount(0);
    if (definition.type === "Value")
      await expect(
        page
          .getByText("CURRENT", { exact: true })
          .locator("..")
          .getByText("6", { exact: true }),
      ).toBeVisible();
    await page
      .getByRole("button", { name: "Discard Changes", exact: true })
      .click();
    await expect(chart).toBeVisible();
    await expect(plot).toHaveCount(1);
  }
  const dashboardResponse = await page.request.post(
    `/api/${createdProject.id}/dashboards`,
    { data: { name: "Grouped dashboard", favorite: false } },
  );
  const dashboard = z
    .object({ id: z.number() })
    .parse(await dashboardResponse.json());
  expect(
    (
      await page.request.put(
        `/api/${createdProject.id}/dashboards/${dashboard.id}/insights`,
        { data: { insight_ids: ids } },
      )
    ).ok(),
  ).toBeTruthy();
  await page.goto(`/app/${createdProject.id}/dashboards/${dashboard.id}`);
  await expect(page.getByTestId("breakdown-group")).toHaveCount(0);
  await expect(page.locator("[data-chart-minimum]")).toHaveCount(6);
  await expect(page.getByTestId("chart-series")).toHaveCount(15);
  await expect(page.getByText(/Error:/)).toHaveCount(0);
  expect(errors).toEqual([]);
});
